#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/usr/local/apps/lib"
XSLT_LIBS="-lxslt  -L/usr/local/apps/lib -lxml2 -L/usr/local/apps/lib -lz -L/usr/local/apps/lib -liconv -lm -ldl -lm -lrt"
XSLT_INCLUDEDIR="-I/usr/local/apps/include"
MODULE_VERSION="xslt-1.1.27"
