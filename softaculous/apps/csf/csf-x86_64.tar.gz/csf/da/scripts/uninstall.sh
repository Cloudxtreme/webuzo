#!/bin/sh

echo "This plugin is uninstalled by uninstalling csf from the root shell"

exit 0;
