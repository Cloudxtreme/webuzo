#!/bin/sh

echo "This plugin is installed by installing csf from the root shell"

exit 0;
