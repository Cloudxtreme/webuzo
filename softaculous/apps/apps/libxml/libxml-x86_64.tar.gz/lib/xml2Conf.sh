#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/usr/local/apps/lib"
XML2_LIBS="-lxml2 -L/usr/local/apps/lib -lz  -L/usr/local/apps/lib -liconv -lm "
XML2_INCLUDEDIR="-I/usr/local/apps/include/libxml2 -I/usr/local/apps/include"
MODULE_VERSION="xml2-2.9.0"

